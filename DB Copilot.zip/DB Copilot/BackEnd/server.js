const express = require("express");
const cors = require("cors");

const { poolPromise } = require("./db");
const loginRoute = require("./routes/login");
const databaseRoute = require("./routes/database");
const agentRoute = require("./routes/agent.routes");

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/login", loginRoute);
app.use("/api/database", databaseRoute);
app.use("/api/agent", agentRoute);

// Test Route
app.get("/test-db", async (req, res) => {
    try {
        const pool = await poolPromise;
        if (!pool) {
            throw new Error("ไม่สามารถเชื่อมต่อฐานข้อมูลได้ (Pool is null)");
        }

        const result = await pool.request().query("SELECT GETDATE() AS ServerTime");
        res.json(result.recordset);
    } catch (err) {
        console.error("Test DB Error:", err.message);
        res.status(500).json({
            success: false,
            error: err.message
        });
    }
});

app.get("/", (req, res) => {
    res.send("DB Copilot API Running");
});

// Start Server & Test DB Connection
const PORT = process.env.PORT || 3000;

app.listen(PORT, async () => {
    console.log(`🚀 Server running on port ${PORT}`);
    
    // ตรวจสอบการเชื่อมต่อ DB ทันทีที่รัน Server
    try {
        await poolPromise;
        console.log("✅ SQL Server Connected successfully!");
    } catch (err) {
        console.error("❌ SQL Server Connection Failed:", err.message);
    }
});