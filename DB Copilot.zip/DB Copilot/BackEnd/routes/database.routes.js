const express = require("express");
const router = express.Router();
const databaseController = require("../controllers/databaseController");

router.post("/connect", databaseController.connect);
router.post("/disconnect", databaseController.disconnect);
router.get("/schema", databaseController.getSchema);
router.post("/query", databaseController.runQuery);
router.get("/status", databaseController.status);

module.exports = router;

// In your main app.js / server.js:
//
//   const databaseRoutes = require("./routes/database.routes");
//   app.use("/api/database", databaseRoutes);
//
// Endpoints become:
//   POST   /api/database/connect
//   POST   /api/database/disconnect
//   GET    /api/database/schema
//   POST   /api/database/query
//   GET    /api/database/status
