const express = require("express");
const router = express.Router();

const databaseController = require("../controllers/databaseController");


// Connect Database
router.post("/connect", databaseController.connect);


// Disconnect Database
router.post("/disconnect", databaseController.disconnect);


// Get Database Schema
router.get("/schema", databaseController.getSchema);


// Execute Query
router.post("/query", databaseController.runQuery);


// Check Database Status
router.get("/status", databaseController.status);


module.exports = router;