-- ============================================================
-- สร้าง SQL Login แยกสำหรับ AI โดยเฉพาะ
-- จำกัดสิทธิ์จริงระดับ SQL Server ไม่ใช่แค่ระดับ prompt/โค้ด
--
-- แนวคิด: ต่อให้ AI (หรือใครก็ตาม) พยายามยิงคำสั่งข้าม database
-- ผ่าน connection นี้ SQL Server จะปฏิเสธเองตั้งแต่ระดับ engine
-- ============================================================

USE master;
GO


-- 1) Create Login
IF NOT EXISTS (
    SELECT 1
    FROM sys.server_principals
    WHERE name = 'ai_copilot_reader'
)
BEGIN
    CREATE LOGIN ai_copilot_reader
    WITH PASSWORD = 'P@ssw0rd';
END
GO


-- 2) Hide other databases
DENY VIEW ANY DATABASE TO ai_copilot_reader;
GO


-- 3) Target Database
USE Training_Trainee02;
GO


-- 4) Create Database User
IF NOT EXISTS (
    SELECT 1
    FROM sys.database_principals
    WHERE name = 'ai_copilot_reader'
)
BEGIN
    CREATE USER ai_copilot_reader
    FOR LOGIN ai_copilot_reader;
END
GO


-- 5) Read only
ALTER ROLE db_datareader
ADD MEMBER ai_copilot_reader;
GO


-- 6) Allow AI read schema
GRANT VIEW DEFINITION TO ai_copilot_reader;
GO


-- 7) Optional: database metadata
GRANT VIEW DATABASE STATE TO ai_copilot_reader;
GO

-- ============================================================
-- ผลลัพธ์หลังรันสคริปต์นี้:
-- - ai_copilot_reader ล็อกอินเข้า SQL Server ได้
-- - เห็น/query ได้เฉพาะฐานข้อมูล HR_DEV เท่านั้น
-- - ฐานข้อมูลอื่นบนเซิร์ฟเวอร์เดียวกัน "มองไม่เห็น" เลย (ไม่ใช่แค่ query ไม่ได้)
-- - query ได้แค่ SELECT (อ่านอย่างเดียว) ผ่าน db_datareader
--
-- ขั้นตอนถัดไป: เอา username/password นี้ไปใส่ในฟอร์ม Connect Database
-- แทนที่จะใช้ "sa" หรือ account ที่มีสิทธิ์เต็ม
-- ============================================================
