const { poolPromise, sql } = require("../db");


exports.logout = async (req,res)=>{
console.log("Logout API User =", req.body.username);
    try{

        const { username } = req.body;


        const pool = await poolPromise;


        const result = await pool.request()

            .input(
                "P_USER_NAME",
                sql.NVarChar(100),
                username
            )

            .execute("SP_1001_P2P_Delete_Active_Session");


        const logoutResult = result.recordset[0];


        return res.json({

            success: logoutResult.SUCCESS === 1,

            message: logoutResult.MESSAGE
            
        });


    }
    catch(err){

        console.error(err);

        return res.status(500).json({

            success:false,

            message:err.message

        });

    }

};