const axios = require("axios");

const {
    getActiveConnection,
    getPool
} = require("../services/database/sqlServer");

const {
    isSafeQuery
} = require("../services/database/queryGuard");


// =====================================================
// POST /api/agent/chat
// =====================================================
exports.chat = async (req, res) => {

    const { message } = req.body;


    if (!message) {
        return res.status(400).json({
            success:false,
            message:"Message required"
        });
    }


    try {

        const connection = getActiveConnection();


        const systemPrompt = `
คุณคือ DB Copilot

หน้าที่:
- ช่วยวิเคราะห์ SQL
- ช่วยออกแบบ Database
- ช่วย Query Database

ข้อจำกัด:

${connection 
? `
Connected Database:
${connection.database}

คุณสามารถใช้งานได้เฉพาะ Database นี้เท่านั้น
`
:
`
ยังไม่มี Database Connection
`
}

ห้าม:
- DROP TABLE
- DELETE
- UPDATE
- INSERT
- เข้าถึง Database อื่น
`;



        // ส่งให้ Ollama

        const aiResponse = await axios.post(
            "http://localhost:11434/api/chat",
            {
                model:"qwen2.5-coder:3b",
                stream:false,

                keep_alive:"10m",

                options:{
                    num_predict:800,
                    temperature:0.2
                },

                messages:[
                    {
                        role:"system",
                        content:systemPrompt
                    },
                    {
                        role:"user",
                        content:message
                    }
                ]
            }
        );


        const answer =
            aiResponse.data.message.content;



        res.json({

            success:true,

            answer

        });



    } catch(error){

        console.error(error);


        res.status(500).json({

            success:false,

            message:error.message

        });

    }

};