const axios = require("axios");

const {
    getActiveConnection,
    getPool
} = require("../services/database/sqlServer");

const {
    isSafeQuery
} = require("../services/database/queryGuard");


// =====================================================
// POST /api/agent/chat
// =====================================================
exports.chat = async (req, res) => {

    console.log("========== AGENT REQUEST ==========");
    console.log(req.body);

    const { message, page } = req.body;

    const mode = page || "assistant";

    if (!message) {
        return res.status(400).json({
            success: false,
            message: "Message required"
        });
    }

    try {
        // 1. เช็คการเชื่อมต่อ Database ก่อนทุกครั้ง
        const connection = getActiveConnection();
        const hasDatabase = connection !== null && connection !== undefined;

        let tableSchemaString = "ไม่พบข้อมูลโครงสร้างตาราง";
        let procedureString = "ไม่พบ Stored Procedure";
        let functionString = "ไม่พบ Function";
        let viewString = "ไม่พบ View";
        let triggerString = "ไม่พบ Trigger";
        let sequenceString = "ไม่พบ Sequence";
        let synonymString = "ไม่มี Synonym";
        let relationshipString = "ไม่พบ Foreign Key";
        let primaryKeyString = "ไม่พบ Primary Key";

        //if (!connection) {
        //    return res.status(400).json({
        //        success: false,
        //       answer: "ยังไม่ได้เชื่อมต่อกับ Database กรุณาเชื่อมต่อฐานข้อมูลก่อนใช้งานครับ"
        //    });
        //}

        // 2. ดึงโครงสร้างตารางและคอลัมน์ทั้งหมดแบบอัตโนมัติ
        if(hasDatabase){

            const pool = await getPool();

            try {
                const schemaResult = await pool.request().query(`
                    SELECT 
                        c.TABLE_SCHEMA,
                        c.TABLE_NAME,
                        c.COLUMN_NAME,
                        c.DATA_TYPE,
                        c.CHARACTER_MAXIMUM_LENGTH,
                        c.IS_NULLABLE,
                            COLUMNPROPERTY(
                                            OBJECT_ID(c.TABLE_SCHEMA+'.'+c.TABLE_NAME),
                                            c.COLUMN_NAME,
                                            'IsIdentity'
                            ) AS IS_IDENTITY
                    FROM INFORMATION_SCHEMA.COLUMNS c
                    JOIN INFORMATION_SCHEMA.TABLES t 
                        ON c.TABLE_SCHEMA = t.TABLE_SCHEMA 
                        AND c.TABLE_NAME = t.TABLE_NAME
                    WHERE t.TABLE_TYPE = 'BASE TABLE'
                    ORDER BY 
                        c.TABLE_SCHEMA,
                        c.TABLE_NAME,
                        c.ORDINAL_POSITION
                `);

                if (schemaResult && schemaResult.recordset) {
                    const tableMap = {};
                    schemaResult.recordset.forEach(row => {
                        const fullName = `[${row.TABLE_SCHEMA}].[${row.TABLE_NAME}]`;
                        if (!tableMap[fullName]) tableMap[fullName] = [];
                        tableMap[fullName].push(
                        `${row.COLUMN_NAME} (${row.DATA_TYPE}${
                        row.CHARACTER_MAXIMUM_LENGTH 
                        ? `(${row.CHARACTER_MAXIMUM_LENGTH})`
                        : ""
                        } ${row.IS_NULLABLE === "NO" ? "NOT NULL" : "NULL"}${
                        row.IS_IDENTITY === 1 ? " IDENTITY" : ""
                        })`
                        );
                    });

                    tableSchemaString = Object.entries(tableMap)
                        .map(([tableName, cols]) => `- ${tableName} (คอลัมน์: ${cols.join(", ")})`)
                        .join("\n");
                }
                const spResult = await pool.request().query(`
                    SELECT
                        SPECIFIC_SCHEMA,
                        SPECIFIC_NAME
                    FROM INFORMATION_SCHEMA.ROUTINES
                    WHERE ROUTINE_TYPE='PROCEDURE'
                    ORDER BY SPECIFIC_SCHEMA,SPECIFIC_NAME
                `);

                if(spResult.recordset.length){

                    procedureString = spResult.recordset
                        .map(r=>`- [${r.SPECIFIC_SCHEMA}].[${r.SPECIFIC_NAME}]`)
                        .join("\n");

                }
                const functionResult = await pool.request().query(`
                    SELECT
                        ROUTINE_SCHEMA,
                        ROUTINE_NAME,
                        ROUTINE_TYPE
                    FROM INFORMATION_SCHEMA.ROUTINES
                    WHERE ROUTINE_TYPE='FUNCTION'
                    ORDER BY ROUTINE_SCHEMA, ROUTINE_NAME
                `);

                if(functionResult.recordset.length){

                    functionString = functionResult.recordset
                        .map(f=>`- [${f.ROUTINE_SCHEMA}].[${f.ROUTINE_NAME}]`)
                        .join("\n");
                }
                const viewResult = await pool.request().query(`
                    SELECT
                        TABLE_SCHEMA,
                        TABLE_NAME
                    FROM INFORMATION_SCHEMA.VIEWS
                    ORDER BY TABLE_SCHEMA,TABLE_NAME
                `);

                if(viewResult.recordset.length){

                    viewString = viewResult.recordset
                        .map(v=>`- [${v.TABLE_SCHEMA}].[${v.TABLE_NAME}]`)
                        .join("\n");
                }

                const triggerResult = await pool.request().query(`
                    SELECT
                        OBJECT_SCHEMA_NAME(parent_id) AS TABLE_SCHEMA,
                        OBJECT_NAME(parent_id) AS TABLE_NAME,
                        name AS TRIGGER_NAME
                    FROM sys.triggers
                    ORDER BY TABLE_SCHEMA,TABLE_NAME
                `);

                if(triggerResult.recordset.length){

                    triggerString = triggerResult.recordset
                        .map(t=>`- ${t.TRIGGER_NAME} -> [${t.TABLE_SCHEMA}].[${t.TABLE_NAME}]`)
                        .join("\n");
                }

                const synonymResult = await pool.request().query(`
                    SELECT
                        SCHEMA_NAME(schema_id) AS SCHEMA_NAME,
                        name,
                        base_object_name
                    FROM sys.synonyms
                    ORDER BY SCHEMA_NAME,name
                `);

                if(synonymResult.recordset.length){

                    synonymString = synonymResult.recordset
                        .map(s=>`- [${s.SCHEMA_NAME}].[${s.name}] -> ${s.base_object_name}`)
                        .join("\n");
                }

                const sequenceResult = await pool.request().query(`
                    SELECT
                        SCHEMA_NAME(schema_id) AS SCHEMA_NAME,
                        name
                    FROM sys.sequences
                    ORDER BY SCHEMA_NAME,name
                `);

                if(sequenceResult.recordset.length){

                    sequenceString = sequenceResult.recordset
                        .map(s=>`- [${s.SCHEMA_NAME}].[${s.name}]`)
                        .join("\n");

                }
                
                const fkResult = await pool.request().query(`
                    SELECT
                        fk.name AS FK_NAME,
                        OBJECT_SCHEMA_NAME(fkc.parent_object_id) AS CHILD_SCHEMA,
                        OBJECT_NAME(fkc.parent_object_id) AS CHILD_TABLE,
                        pc.name AS CHILD_COLUMN,

                        OBJECT_SCHEMA_NAME(fkc.referenced_object_id) AS PARENT_SCHEMA,
                        OBJECT_NAME(fkc.referenced_object_id) AS PARENT_TABLE,
                        rc.name AS PARENT_COLUMN
                    FROM sys.foreign_keys fk
                    JOIN sys.foreign_key_columns fkc
                        ON fk.object_id = fkc.constraint_object_id
                    JOIN sys.columns pc
                        ON pc.object_id = fkc.parent_object_id
                    AND pc.column_id = fkc.parent_column_id
                    JOIN sys.columns rc
                        ON rc.object_id = fkc.referenced_object_id
                    AND rc.column_id = fkc.referenced_column_id
                    ORDER BY CHILD_SCHEMA, CHILD_TABLE;
                `);
                if(fkResult.recordset.length){

                    relationshipString = fkResult.recordset
                        .map(r =>
                            `- [${r.CHILD_SCHEMA}].[${r.CHILD_TABLE}].${r.CHILD_COLUMN}
                            -> [${r.PARENT_SCHEMA}].[${r.PARENT_TABLE}].${r.PARENT_COLUMN}`
                        )
                        .join("\n");
                }

                const pkResult = await pool.request().query(`
                    SELECT
                        TC.CONSTRAINT_NAME,
                        KU.TABLE_SCHEMA,
                        KU.TABLE_NAME,
                        STUFF(
                                (
                                    SELECT 
                                        ', ' + KU2.COLUMN_NAME
                                    FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE KU2
                                    WHERE KU2.CONSTRAINT_NAME = TC.CONSTRAINT_NAME
                                    ORDER BY KU2.ORDINAL_POSITION
                                    FOR XML PATH('')
                                ),
                                1,
                                2,
                                ''
                            ) AS PK_COLUMNS
                    FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS TC
                    JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE KU
                        ON TC.CONSTRAINT_NAME = KU.CONSTRAINT_NAME
                    WHERE TC.CONSTRAINT_TYPE='PRIMARY KEY'
                    GROUP BY
                        TC.CONSTRAINT_NAME,
                        KU.TABLE_SCHEMA,
                        KU.TABLE_NAME
                    ORDER BY
                        KU.TABLE_SCHEMA,
                        KU.TABLE_NAME;
                `);
                if(pkResult.recordset.length){

                    primaryKeyString = pkResult.recordset
                        .map(r =>
                            `- [${r.TABLE_SCHEMA}].[${r.TABLE_NAME}] : ${r.PK_COLUMNS}`
                        )
                        .join("\n");
                }
                // =============================
                // DEBUG
                // =============================
                console.log("===== DATABASE METADATA =====");
                console.log("Database:", connection.database);
                console.log("Table Schema Length:", tableSchemaString.length);
                console.log(tableSchemaString.substring(0,1000));

                console.log("Procedure Length:", procedureString.length);
                console.log("View Length:", viewString.length);
                console.log("Function Length:", functionString.length);
                console.log("FK Length:", relationshipString.length);
                console.log("PK Length:", primaryKeyString.length);
            } catch (schemaError) {
                console.error("Could not fetch table schema:", schemaError.message);
            }
        }

        // 3. กำหนด System Prompt ให้ AI ฉลาดในการจับคู่ชื่อตาราง (รองรับรูปแบบยืดหยุ่น)
        const sharedPrompt = `

        คุณคือ DB Copilot
        AI Assistant สำหรับช่วยงาน Database Design และ SQL Development

        หน้าที่
        - ช่วยออกแบบ Database
        - ช่วยวิเคราะห์ SQL
        - ตอบตาม Mode ที่ได้รับเท่านั้น
        - หากคำถามอยู่นอก Mode ให้แนะนำผู้ใช้ไปยัง Mode ที่เหมาะสม

        ${connection
        ? `

        =========================
        DATABASE STATUS
        =========================

        Database Connected

        DB Copilot เชื่อมต่อกับ Database สำเร็จแล้ว

        Database Name:
        ${connection.database}

        Metadata ทั้งหมดด้านล่างเป็นข้อมูลจริงที่ดึงมาจาก Database ปัจจุบัน

        คุณต้องถือว่าคุณสามารถเข้าถึงข้อมูลนี้ได้

        ห้ามตอบว่า
        - ไม่สามารถเข้าถึงฐานข้อมูล
        - ไม่มีสิทธิ์เข้าถึงฐานข้อมูล
        - กรุณาส่ง Schema
        - กรุณาส่ง Table
        - กรุณาระบุ Database

        เพราะข้อมูลทั้งหมดถูกส่งมาใน Prompt แล้ว

        เมื่อผู้ใช้ถามเกี่ยวกับ
        - Table
        - Column
        - Primary Key
        - Foreign Key
        - View
        - Function
        - Stored Procedure
        - Trigger
        - Relationship
        - Database Structure

        ให้ตอบจาก Metadata ด้านล่างทันที

        หากไม่พบข้อมูลใน Metadata
        ให้ตอบว่า

        "ไม่พบข้อมูลดังกล่าวใน Database ที่เชื่อมต่ออยู่"

        ห้ามบอกว่าเข้าถึง Database ไม่ได้

        =========================
        TABLES
        =========================
        ${tableSchemaString}

        =========================
        STORED PROCEDURES
        =========================
        ${procedureString}

        =========================
        FUNCTIONS
        =========================
        ${functionString}

        =========================
        VIEWS
        =========================
        ${viewString}

        =========================
        TRIGGERS
        =========================
        ${triggerString}

        =========================
        SEQUENCES
        =========================
        ${sequenceString}

        =========================
        SYNONYMS
        =========================
        ${synonymString}

        =========================
        PRIMARY KEYS
        =========================
        ${primaryKeyString}

        =========================
        FOREIGN KEYS
        =========================
        ${relationshipString}

        Database Rules

        - ใช้เฉพาะ Metadata ที่ให้มา
        - ห้ามสร้างชื่อ Table หรือ Column ที่ไม่มีอยู่
        - หากออกแบบ Database ใหม่ สามารถสร้าง Table ใหม่ได้
        - หากเป็น Database ปัจจุบัน ต้องอ้างอิง Metadata เท่านั้น

        `
        : `

        =========================
        DATABASE STATUS
        =========================

        No Database Connection

        กฎการทำงาน

        สามารถตอบได้
        - Database Design
        - Database Concept
        - SQL Concept
        - Performance Concept
        - Workflow Design
        - ER Diagram
        - Database ใหม่จาก Requirement

        ห้าม
        - อ้างอิง Table จริง
        - อ้างอิง Column จริง
        - Query Database จริง
        - วิเคราะห์ Stored Procedure จริง
        - วิเคราะห์ Relationship จริง
        - Debug SQL ที่อ้างอิง Database ปัจจุบัน

        หากคำถามต้องใช้ข้อมูลจริงจาก Database เช่น

        - Table ที่มีอยู่
        - Column
        - Query ข้อมูล
        - Stored Procedure
        - Relationship
        - Database Structure ปัจจุบัน

        ให้ตอบเพียงว่า

        "คำถามนี้จำเป็นต้องใช้ข้อมูลจาก Database จริงครับ
        กรุณาเชื่อมต่อ Database ก่อน เพื่อให้ DB Copilot วิเคราะห์ข้อมูลได้ถูกต้องครับ"

        `
        }

        =========================
        TABLE NAME RULE
        =========================

        หากผู้ใช้เรียกชื่อตารางไม่ตรง เช่น

        - SysMenu
        - tb_SysMenu
        - Sys_Menu

        ให้ Mapping ไปยังชื่อจริงใน Metadata ก่อนเสมอ

        ห้ามสร้างชื่อ Table หรือ Column ขึ้นเอง

        =========================
        SECURITY RULE
        =========================

        ห้าม Execute

        - DROP
        - DELETE
        - UPDATE
        - INSERT
        - ALTER
        - TRUNCATE
        - EXEC
        - EXECUTE

        สามารถแสดง SQL Script ตัวอย่างได้
        แต่ห้าม Execute คำสั่งที่แก้ไขข้อมูลจริง

        `;


        // =============================
        // MODE PROMPT
        // แยกความสามารถตามหน้าใช้งาน
        // SHARED LOGIC
        // Design / Assistant ใช้ Router ตัวเดียวกัน
        // =============================

        let systemPrompt = sharedPrompt;


        // Database Design Mode
        if (mode === "design") {

            systemPrompt += `

        Mode:
        Database Design Assistant

        หน้าที่

        - วิเคราะห์ Requirement
        - ออกแบบ Workflow
        - ออกแบบ Database Structure
        - ออกแบบ Table
        - ออกแบบ Column
        - ออกแบบ Primary Key
        - ออกแบบ Foreign Key
        - ออกแบบ Relationship
        - ออกแบบ Database Schema
        - ออกแบบระบบใหม่จาก Business Requirement

        การทำงาน

        หาก Database Connected

        - ใช้ Metadata ที่ได้รับเป็นข้อมูลอ้างอิง
        - ใช้ Table และ Column ที่มีอยู่ก่อนเสมอ
        - หากสามารถใช้ Table เดิมได้ ห้ามสร้าง Table ใหม่
        - หากต้องสร้าง Table ใหม่ ให้เชื่อมโยงกับโครงสร้างเดิม
        - ตั้งชื่อ Table และ Column ให้สอดคล้องกับ Naming Convention ของ Database
        - ห้ามสร้างชื่อ Table หรือ Column ที่ซ้ำกับของเดิม
        - เมื่อตรวจสอบ Table, Column, View, Function, Stored Procedure หรือ Relationship ให้ตอบจาก Metadata ที่ได้รับเท่านั้น
        - หากไม่พบข้อมูลใน Metadata ให้ตอบว่า
        "ไม่พบข้อมูลดังกล่าวใน Database ที่เชื่อมต่ออยู่"

        หาก Database Not Connected

        - สามารถออกแบบ Database ใหม่ได้
        - สามารถออกแบบ Workflow ได้
        - สามารถออกแบบ ER Diagram ได้
        - ห้ามอ้างอิง Table หรือ Column จริงของ Database

        รูปแบบการตอบ

        1. Requirement Summary
        2. Workflow
        3. Database Structure
        4. Table Design
        5. Relationship
        6. Schema Summary
        7. ข้อเสนอแนะเพิ่มเติม (ถ้ามี)

        ห้าม

        - วิเคราะห์ SQL
        - Debug SQL
        - Optimize SQL
        - วิเคราะห์ Performance
        - วิเคราะห์ Execution Plan
        - แนะนำ Index
        - Generate SQL สำหรับ Production

        หากผู้ใช้ร้องขอ SQL Script

        - สามารถสร้าง SQL Script สำหรับการออกแบบ Database ได้
        - ห้ามสร้าง SQL เพื่อวิเคราะห์หรือแก้ไข Performance

        หากผู้ใช้ถามเกี่ยวกับ

        - SQL Query
        - SQL Error
        - Query Performance
        - SQL Optimization
        - Stored Procedure Analysis
        - Execution Plan
        - Index
        - Database Performance
        - SQL Debug

        ให้ตอบว่า

        "ขออภัยครับ คำถามนี้อยู่นอกขอบเขตของ Database Design กรุณาใช้งาน SQL Assistant Mode เพื่อช่วยวิเคราะห์ SQL และ Performance ครับ"

        `;

        }


        // SQL Assistant Mode
        else if (mode === "assistant") {

            systemPrompt += `

        Mode:
        SQL Assistant

        หน้าที่

        - วิเคราะห์ SQL Query
        - Debug SQL Error
        - ปรับปรุง Query
        - Optimize SQL Performance
        - วิเคราะห์ Stored Procedure
        - วิเคราะห์ Function
        - วิเคราะห์ View
        - อธิบาย Execution Plan
        - วิเคราะห์ Database Performance
        - แนะนำ Index

        การทำงาน

        หาก Database Connected

        - ใช้ Metadata ที่ได้รับเป็นข้อมูลอ้างอิง
        - ใช้เฉพาะ Table และ Column ที่มีอยู่ใน Database
        - หากผู้ใช้เรียกชื่อตารางไม่ตรง ให้ Mapping ไปยังชื่อจริง
        - หากไม่พบ Table หรือ Column ใน Metadata ให้ตอบว่า
        "ไม่พบข้อมูลดังกล่าวใน Database ที่เชื่อมต่ออยู่"
        - ห้ามเดาชื่อ Table หรือ Column
        - รักษา Business Logic ของ Query เดิม
        - หากจำเป็นต้องเปลี่ยน Logic ให้แจ้งเหตุผลก่อน

        เมื่อสร้าง SQL

        - ใช้ชื่อ Table และ Column จริงจาก Metadata
        - เขียน SQL ภายใน Markdown Code Block เสมอ
        - Query สำหรับอ่านข้อมูลต้องจำกัดจำนวนข้อมูล เช่น
        - SELECT TOP 100
        - OFFSET / FETCH
        - หลีกเลี่ยง Query ที่ดึงข้อมูลทั้งหมดโดยไม่มี Limit

        หาก Database Not Connected

        สามารถ

        - อธิบาย SQL Syntax
        - วิเคราะห์ SQL Logic
        - อธิบาย Function ของ SQL
        - ยกตัวอย่าง SQL
        - ให้คำแนะนำด้าน Performance Concept

        ห้าม

        - อ้างอิง Table หรือ Column จริง
        - เดาชื่อ Table
        - เดาชื่อ Column
        - วิเคราะห์ Database ปัจจุบัน

        รูปแบบการตอบ

        1. วิเคราะห์ปัญหา
        2. สาเหตุที่เป็นไปได้
        3. แนวทางแก้ไข
        4. SQL ตัวอย่าง (ถ้ามี)
        5. ข้อควรระวัง
        6. คำแนะนำเพิ่มเติม (ถ้ามี)

        ห้าม

        - ออกแบบ Database ใหม่
        - ออกแบบ Workflow
        - ออกแบบ Database Structure
        - ออกแบบ Table
        - ออกแบบ Column
        - ออกแบบ Primary Key
        - ออกแบบ Foreign Key
        - ออกแบบ Relationship
        - สร้าง Database Schema ใหม่

        หากผู้ใช้ถามเกี่ยวกับ

        - Database Design
        - Table Design
        - Entity Relationship
        - Workflow Design
        - Database Structure
        - Database Schema

        ให้ตอบว่า

        "ขออภัยครับ คำถามนี้อยู่นอกขอบเขตของ SQL Assistant กรุณาใช้งาน Database Design Mode เพื่อช่วยออกแบบโครงสร้างระบบครับ"

        `;

        }


        // กรณีไม่มี Mode
        else{

                systemPrompt += `

            Mode:
            General DB Assistant

            กรุณาให้คำตอบเกี่ยวกับ Database อย่างเหมาะสม

            `;
        }
        console.log("========== SYSTEM PROMPT ==========");
        console.log(systemPrompt);
        // 4. ส่งให้ Ollama แปลงคำถามเป็น SQL
        const aiResponse = await axios.post(
            "http://localhost:11434/api/chat",
            {
                model: "qwen2.5-coder:3b",
                stream: false,
                keep_alive: "10m",
                options: {
                    num_predict: 800,
                    temperature: 0.2
                },
                messages: [
                    {
                        role: "system",
                        content: systemPrompt
                    },
                    {
                        role: "user",
                        content: message
                    }
                ]
            }
        );

        const answerText = aiResponse.data.message.content;

        // 5. ดึง SQL ออกมาจาก Markdown Code Block ที่ AI ตอบกลับมา
        const sqlMatch =answerText.match(/```sql\s*([\s\S]*?)\s*```/) || answerText.match(/```\s*([\s\S]*?)\s*```/);        
        let queryResult = null;

        if (sqlMatch && sqlMatch[1] && hasDatabase) {
            let sqlQuery = sqlMatch[1].trim();

            // 6. [เพิ่มเติมความยืดหยุ่น] เผื่อกรณีที่ AI ดันเผลอใส่ชื่อตารางมี prefix แปลกๆ (เช่น tb_SysMenu) 
            // ระบบจะช่วยแปลงให้เข้ากับโครงสร้างจริงที่มีอยู่ใน DB ก่อนนำไปรัน (ถ้าจำเป็น)
            // แต่เนื่องจากเราใส่ตารางจริงทั้งหมดให้ AI ดูใน System Prompt แล้ว AI จะเลือกใช้ชื่อจริงจากในนั้นโดยอัตโนมัติ

            // 7. เช็คความปลอดภัยของ SQL ผ่าน queryGuard
            const allowedDbName = connection.database || "";
            const safetyCheck = isSafeQuery(sqlQuery, allowedDbName);

            if (safetyCheck.safe) {
                try {
                    // 8. รัน SQL กับ Database จริง
                    const result = await pool.request().query(sqlQuery);
                    queryResult = result.recordset;

                    // 9. ส่งผลลัพธ์จาก DB กลับไปให้ AI สรุปเป็นภาษาพูด
                    const summaryResponse = await axios.post(
                        "http://localhost:11434/api/chat",
                        {
                            model: "qwen2.5-coder:3b",
                            stream: false,
                            messages: [
                                {
                                    role: "system",
                                    content: "คุณคือ DB Copilot หน้าที่คือสรุปผลลัพธ์จากข้อมูล Database ที่ให้มา เป็นภาษาพูดที่เข้าใจง่าย สั้นกระชับ เป็นกันเอง"
                                },
                                {
                                    role: "user",
                                    content: `คำถามของผู้ใช้: "${message}" \n\n ผลลัพธ์จาก Database ที่ได้คือ: ${JSON.stringify(queryResult)} \n\n ช่วยสรุปคำตอบให้ผู้ใช้หน่อยครับ`
                                }
                            ],
                            keep_alive:"10m",
                            options:{
                            num_predict:300,
                            temperature:0.2
                            }
                        }
                    );

                    const finalAnswer = summaryResponse.data.message.content;

                    return res.json({
                        success: true,
                        answer: finalAnswer,
                        sql: sqlQuery,
                        data: queryResult
                    });

                } catch (dbError) {
                    console.error("DB Execution Error:", dbError);
                    return res.status(500).json({
                        success: false,
                        message: `DB Execution Error: ${dbError.message}`
                    });
                }
            } else {
                // ถ้าไม่ผ่านระบบความปลอดภัย
                return res.json({
                    success: false,
                    answer: `ไม่สามารถรันคำสั่งนี้ได้ เนื่องจาก: ${safetyCheck.reason}`
                });
            }
        }

        // กรณีเป็นคำถามทั่วไปที่ไม่มี SQL
        res.json({
            success: true,
            answer: answerText
        });

    } catch (error) {
        console.error("Controller Error:", error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};