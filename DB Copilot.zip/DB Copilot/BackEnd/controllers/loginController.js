const { poolPromise, sql } = require("../db");


exports.login = async (req, res) => {

    try {

        const { username, password } = req.body;


        const pool = await poolPromise;


        const result = await pool.request()

            .input(
                "p_user_name",
                sql.NVarChar(100),
                username
            )

            .input(
                "p_password",
                sql.NVarChar(100),
                password
            )

            .execute("SP_1001_P2P_Check_User_Permission");


        const loginResult = result.recordset[0];

        //const data = result.recordset[0];

        if(loginResult.is_permission === 1){

            const sessionResult = await pool.request()

                .input(
                    "P_USER_NAME",
                    sql.NVarChar(100),
                    username
                )

                .execute("SP_1001_P2P_Check_Active_Session");


            const session = sessionResult.recordset[0];

            if(!session){

                return res.json({

                    success:false,

                    message:"Session creation failed"

                });

            }
            return res.json({

                success: session.SUCCESS === 1,

                message: session.MESSAGE,

                user_name: loginResult.user_name,

                user_name_ad: session.USER_NAME,

                session_id: session.SESSION_ID,

                expire_time: session.EXPIRE_TIME

            });

        }
        else{

            return res.json({

                success:false,

                message:"Invalid username or password"

            });

        }
    }
    catch(err){

        console.error(err);

        res.status(500).json({

            success:false,

            message:err.message

        });

    }

};