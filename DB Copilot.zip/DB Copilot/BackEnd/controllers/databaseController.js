const {
  connectSqlServer,
  disconnectSqlServer,
  getActiveConnection,
  getPool
} = require("../services/database/sqlServer");

const { isSafeQuery } = require("../services/database/queryGuard");


exports.connect = async (req, res) => {
  const { type, server, database, username, password } = req.body;

  try {
    let context;

    switch (type) {
      case "SQL Server":
        context = await connectSqlServer({
          server,
          database,
          username,
          password
        });
        break;

      case "Oracle":
        throw new Error("Oracle not implemented yet");

      default:
        throw new Error("Unsupported Database Type");
    }

    res.json({
      success: true,
      message: "Database Connected",
      context
    });

  } catch (error) {
    console.error(error);
    res.status(400).json({
      success:false,
      message:error.message
    });
  }
};
exports.disconnect = async (req,res)=>{
  try{
    await disconnectSqlServer();

    res.json({
      success:true,
      message:"Disconnected"
    });

  }catch(error){
    console.error(error);

    res.status(500).json({
      success:false,
      message:error.message
    });
  }
};
exports.getSchema = async(req,res)=>{

  const active = getActiveConnection();

  if(!active){
    return res.status(400).json({
      success:false,
      message:"No active connection"
    });
  }


  try{

    const pool = getPool();

    const result = await pool
      .request()
      .input("dbName", active.database)
      .query(`
        SELECT TABLE_NAME,
               COLUMN_NAME,
               DATA_TYPE,
               IS_NULLABLE
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_CATALOG = @dbName
        ORDER BY TABLE_NAME, ORDINAL_POSITION
      `);


    res.json({
      success:true,
      database:active.database,
      columns:result.recordset
    });


  }catch(error){

    console.error(error);

    res.status(500).json({
      success:false,
      message:error.message
    });

  }

};
exports.runQuery = async(req,res)=>{

  const active = getActiveConnection();

  if(!active){
    return res.status(400).json({
      success:false,
      message:"No active connection"
    });
  }


  const {query}=req.body;

  const check=isSafeQuery(query,active.database);


  if(!check.safe){
    return res.status(403).json({
      success:false,
      message:check.reason
    });
  }


  try{

    const pool=getPool();

    const result=await pool
      .request()
      .query(query);


    res.json({
      success:true,
      rows:result.recordset
    });


  }catch(error){

    console.error(error);

    res.status(500).json({
      success:false,
      message:error.message
    });

  }

};
exports.status=(req,res)=>{

  const active=getActiveConnection();

  res.json({
    connected:!!active,
    context:active
  });

};