const sql = require("mssql");


exports.connect = async(req,res)=>{

    const {
        server,
        database,
        username,
        password
    } = req.body;


    const config = {

        server: server,

        database: database,

        user: username,

        password: password,

        options:{
            encrypt:false,
            trustServerCertificate:true
        }

    };


    try{

        const pool = await sql.connect(config);


        await pool.close();


        res.json({

            success:true,

            message:"Database Connected"

        });


    }
    catch(error){

        console.error(error);


        res.json({

            success:false,

            message:error.message

        });

    }

};