const { getPool, getActiveConnection } = require("../database/sqlServer");

/**
 * รันคำสั่ง SQL (ควรผ่านการตรวจสอบความปลอดภัยจาก queryGuard/agentService มาก่อนแล้ว)
 * ใช้ connection pool เดียวกับที่ตั้งค่าไว้ตอน Connect Database (sqlServer.js)
 */
async function query(sql) {

    const pool = getPool();

    if (!pool) {
        throw new Error("ยังไม่ได้เชื่อมต่อ Database กรุณา Connect Database ก่อนใช้งาน");
    }

    const connection = getActiveConnection();
    console.log(`⚡ Query on [${connection?.database || "unknown"}]:`, sql);

    const result = await pool.request().query(sql);

    // recordset คือ array ของแถวข้อมูลที่ query ได้
    return result.recordset;

}

module.exports = { query };
