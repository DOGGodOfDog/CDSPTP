const axios = require("axios");

/**
 * ใช้กับผู้ให้บริการที่ทำ endpoint ตามมาตรฐาน OpenAI Chat Completions
 * เช่น OpenAI, OpenRouter, Groq, DeepSeek, Together AI, ฯลฯ
 *
 * ตั้งค่าผ่าน .env:
 *   AI_BASE_URL = base url ของผู้ให้บริการ (ไม่ต้องมี /chat/completions ต่อท้าย)
 *   AI_API_KEY  = token/api key ที่ซื้อมา
 *   AI_MODEL    = ชื่อโมเดลที่ผู้ให้บริการกำหนด
 */
async function chat(messages, options = {}) {

    const baseURL = process.env.AI_BASE_URL || "https://api.openai.com/v1";
    const apiKey = process.env.AI_API_KEY;
    const model = options.model || process.env.AI_MODEL || "gpt-4o-mini";

    if (!apiKey) {
        throw new Error(
            "AI_API_KEY ไม่ถูกตั้งค่าใน .env — จำเป็นสำหรับ provider แบบซื้อ Token"
        );
    }

    const response = await axios.post(
        `${baseURL}/chat/completions`,
        {
            model,
            temperature: options.temperature ?? 0.2,
            ...(options.numPredict ? { max_tokens: options.numPredict } : {}),
            // ผู้ให้บริการที่รองรับมาตรฐาน OpenAI ใช้ response_format แทน format
            ...(options.format === "json" ? { response_format: { type: "json_object" } } : {}),
            messages
        },
        {
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${apiKey}`
            }
        }
    );

    return response.data.choices[0].message.content;

}


module.exports = {
    chat
};
