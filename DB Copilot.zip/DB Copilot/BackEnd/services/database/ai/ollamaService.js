const axios = require("axios");

async function chat(messages, options = {}) {

    const baseURL = process.env.OLLAMA_BASE_URL || "http://localhost:11434";
    const model = options.model || process.env.OLLAMA_MODEL || "qwen2.5-coder:7b";

    const response = await axios.post(
        `${baseURL}/api/chat`,
        {
            model,
            stream: false,
            keep_alive: options.keepAlive || "10m",
            ...(options.format ? { format: options.format } : {}),
            options: {
                temperature: options.temperature ?? 0.2,
                ...(options.numPredict ? { num_predict: options.numPredict } : {})
            },
            messages
        }
    );

    return response.data.message.content;

}


module.exports = {
    chat
};
