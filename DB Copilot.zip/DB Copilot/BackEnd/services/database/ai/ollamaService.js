const axios = require("axios");


async function chat(messages){

    const response = await axios.post(
        "http://localhost:11434/api/chat",
        {
            model:"qwen2.5-coder:7b",
            stream:false,
            options: {
                temperature: 0.2 // ค่ายิ่งต่ำ AI ยิ่งตอบเป๊ะตามความจริง ไม่มโน
            },
            messages
        }
    );


    return response.data.message.content;

}


module.exports = {
    chat
};