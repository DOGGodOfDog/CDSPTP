const ollamaService = require("./ollamaService");
const openaiService = require("./openaiService");

/**
 * ตัวเลือก provider:
 *   AI_PROVIDER=ollama   -> ใช้ AI local (ฟรี ไม่ต้องมี key) [default]
 *   AI_PROVIDER=openai   -> ใช้ AI แบบซื้อ Token (ต้องตั้ง AI_API_KEY, AI_BASE_URL, AI_MODEL)
 */
function getProvider() {
    const providerName = (process.env.AI_PROVIDER || "ollama").toLowerCase();

    switch (providerName) {
        case "ollama":
            return ollamaService;
        case "openai":
        case "openai-compatible":
            return openaiService;
        default:
            throw new Error(`ไม่รู้จัก AI_PROVIDER: "${providerName}" (รองรับ: ollama, openai)`);
    }
}

async function chat(messages, options = {}) {
    const provider = getProvider();
    return provider.chat(messages, options);
}

module.exports = { chat };
