const ollama = require("./ollamaService");
const databaseTool = require("./databaseTool");

const DB_SCHEMA = `
Database Engine: MS SQL Server
Tables:
1. Users (UserID INT, Username VARCHAR, Email VARCHAR, CreatedAt DATETIME)
2. Orders (OrderID INT, UserID INT, TotalAmount DECIMAL, OrderDate DATETIME, Status VARCHAR)
`;

async function process(message) {
    try {
        // Step 1: วิเคราะห์และขอ SQL
        const decisionRaw = await ollama.chat([
            {
                role: "system",
                content: `คุณคือ AI ผู้เชี่ยวชาญด้าน MS SQL Server
วิเคราะห์คำถามของผู้ใช้ว่าจำเป็นต้องดึงข้อมูลจาก Database หรือไม่

Database Schema:
${DB_SCHEMA}

กฎสำคัญ:
1. ตอบกลับเป็น JSON เท่านั้น
2. สร้างเฉพาะคำสั่ง SELECT เท่านั้น ห้ามใช้ INSERT, UPDATE, DELETE, DROP, ALTER, EXEC
3. ต้องใส่ "TOP 100" ในคำสั่ง SELECT ทุกครั้งเพื่อป้องกันข้อมูลเยอะเกินไป
4. รูปแบบ JSON:
{
  "useTool": true หรือ false,
  "sql": "คำสั่ง SQL Query (ใส่เฉพาะเมื่อ useTool เป็น true เท่านั้น)"
}`
            },
            {
                role: "user",
                content: message
            }
        ], { format: "json" }); // 💡 แนะนำให้ส่ง { format: "json" } ไปที่ ollamaService เพื่อล็อกรูปแบบ

        // 🛠️ ปรับการดึงก้อน JSON ให้ปลอดภัยขึ้น (ดึงเฉพาะก้อน {...})
        let result = { useTool: false, sql: "" };
        try {
            const jsonMatch = decisionRaw.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                result = JSON.parse(jsonMatch[0]);
            }
        } catch (e) {
            console.log("⚠️ Parse JSON ไม่สำเร็จ ใช้โหมดคุยทั่วไปแทน:", decisionRaw);
        }

        // Step 2: กรณีไม่ต้องใช้ Database (คุยทั่วไป)
        if (!result.useTool || !result.sql || typeof result.sql !== 'string') {
            return await ollama.chat([
                {
                    role: "user",
                    content: message
                }
            ]);
        }

        // 🛡️ Guardrail Check แบบใช้ Regex (กัน False Positive เช่น คอลัมน์ IsDeleted)
        const cleanSql = result.sql.trim();
        const isSelectOnly = /^SELECT\s+/i.test(cleanSql);
        const hasForbiddenKeywords = /\b(DELETE|DROP|ALTER|UPDATE|INSERT|TRUNCATE|EXEC|EXECUTE)\b/i.test(cleanSql);

        if (!isSelectOnly || hasForbiddenKeywords) {
            console.warn("⚠️ SQL ไม่ผ่านการตรวจสอบความปลอดภัย:", cleanSql);
            return "ขออภัย ระบบอนุญาตให้ดึงข้อมูลด้วยคำสั่ง SELECT เท่านั้นครับ";
        }

        // Step 3: กรณีต้องใช้ Database
        console.log("⚡ คำสั่ง SQL ที่จะรัน:", cleanSql);
        const data = await databaseTool.query(cleanSql);

        // ป้องกันกรณี Query ผ่าน แต่ส่งข้อมูลกลับมาเยอะเกินไปให้ AI อ่าน
        const safeData = Array.isArray(data) ? data.slice(0, 100) : data;

        // ส่งข้อมูลกลับไปให้ AI ช่วยสรุปคำตอบ
        return await ollama.chat([
            {
                role: "user",
                content: `คำถามของผู้ใช้: ${message}
ข้อมูลที่ดึงได้จาก Database: ${JSON.stringify(safeData)}

ช่วยสรุปและตอบคำถามของผู้ใช้จากข้อมูลด้านบนให้เข้าใจง่ายและเป็นกันเอง`
            }
        ]);

    } catch (error) {
        console.error("❌ Process Error:", error.message);
        return "ขออภัย เกิดข้อผิดพลาดในการประมวลผลข้อมูล";
    }
}

module.exports = { process };