// ------------------------------------------------------------
// This is the REAL enforcement layer. The system prompt tells
// the AI what it's allowed to do; this module makes sure that
// even if the AI (or the user) tries to break that rule, the
// query never actually reaches SQL Server.
//
// Rule of thumb: never trust the model's output — validate it
// the same way you'd validate any untrusted user input.
// ------------------------------------------------------------

const FORBIDDEN_PATTERNS = [
  /\buse\s+\[?\w+\]?/i,        // USE OtherDatabase
  /\bdrop\s+database\b/i,
  /\balter\s+database\b/i,
  /\bcreate\s+database\b/i,
  /\bsp_configure\b/i,
  /\bopenrowset\b/i,
  /\bopendatasource\b/i,
  /\bxp_cmdshell\b/i,
  /\blinked\s*server\b/i,
  /\b\w+\.\w+\.\w+\.\w+\b/      // 4-part naming = cross-SERVER reference
];

/**
 * Checks whether a SQL statement is safe to run against the
 * currently connected database.
 *
 * @param {string} sqlText          The raw SQL the AI wants to run
 * @param {string} allowedDatabase  The database name from the active connection
 * @returns {{ safe: boolean, reason?: string }}
 */
function isSafeQuery(sqlText, allowedDatabase) {
  const trimmed = (sqlText || "").trim();

  if (!trimmed) {
    return { safe: false, reason: "ไม่มีคำสั่ง SQL ให้ตรวจสอบ" };
  }

  // Only ever allow a single read-only SELECT statement.
  // Anything else (INSERT/UPDATE/DELETE/EXEC/multiple statements
  // separated by ;) should go through a separate, explicitly
  // reviewed path — not the AI chat.
  if (!/^select\b/i.test(trimmed)) {
    return { safe: false, reason: "อนุญาตเฉพาะคำสั่ง SELECT เท่านั้น" };
  }

  if (trimmed.includes(";") && trimmed.indexOf(";") < trimmed.length - 1) {
    return { safe: false, reason: "ไม่อนุญาตให้รันหลายคำสั่งพร้อมกัน" };
  }

  for (const pattern of FORBIDDEN_PATTERNS) {
    if (pattern.test(trimmed)) {
      return { safe: false, reason: "คำสั่งมีรูปแบบที่ไม่ได้รับอนุญาต (ระดับ server หรือ cross-database)" };
    }
  }

  // Block explicit three-part references to a different database,
  // e.g. OtherDB.dbo.Table when the active DB is "HR_DEV".
  const dbRefPattern = /\[?(\w+)\]?\.\[?\w+\]?\.\[?\w+\]?/g;
  let match;
  while ((match = dbRefPattern.exec(trimmed)) !== null) {
    const referencedDb = match[1];
    if (referencedDb.toLowerCase() !== allowedDatabase.toLowerCase()) {
      return { safe: false, reason: `ห้ามอ้างอิงฐานข้อมูลอื่น: "${referencedDb}"` };
    }
  }

  return { safe: true };
}

module.exports = { isSafeQuery };
