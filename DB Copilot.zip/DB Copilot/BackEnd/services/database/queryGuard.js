// =====================================================
// SQL SECURITY GATE
// DB Copilot Runtime Protection
// =====================================================


const FORBIDDEN_PATTERNS = [

    // Database switching
    /\buse\s+\[?\w+\]?/i,

    // Database operation
    /\bdrop\s+database\b/i,
    /\balter\s+database\b/i,
    /\bcreate\s+database\b/i,

    // Server access
    /\bsp_configure\b/i,
    /\bopenrowset\b/i,
    /\bopendatasource\b/i,
    /\bxp_cmdshell\b/i,
    /\blinked\s*server\b/i,


    // Cross server reference
    /\b\w+\.\w+\.\w+\.\w+\b/i,


    // Write operation bypass
    /\bselect\s+.*\binto\b/i,


    // Delay attack
    /\bwaitfor\b/i,


    // SQL comment injection
    /--/,
    /\/\*/,
    /\*\//


];



function isSafeQuery(sqlText, allowedDatabase){

    const sql = (sqlText || "").trim();


    if(!sql){

        return {
            safe:false,
            reason:"ไม่มี SQL"
        };

    }



    const upperSQL = sql.toUpperCase();



    // ---------------------------------
    // Only SELECT
    // ---------------------------------

    if(!/^SELECT\b/i.test(sql)){

        return {
            safe:false,
            reason:"อนุญาตเฉพาะ SELECT เท่านั้น"
        };

    }



    // ---------------------------------
    // Block write command
    // ---------------------------------

    const forbiddenKeywords=[

        "INSERT",
        "UPDATE",
        "DELETE",
        "DROP",
        "ALTER",
        "TRUNCATE",
        "MERGE",
        "EXEC",
        "EXECUTE",
        "CREATE"

    ];



    for(const keyword of forbiddenKeywords){

        const regex =
        new RegExp(`\\b${keyword}\\b`,"i");


        if(regex.test(sql)){

            return {

                safe:false,
                reason:`Command ${keyword} is not allowed`

            };

        }

    }




    // ---------------------------------
    // Multiple statements
    // ---------------------------------

    const statements =
    sql.split(";")
    .filter(x=>x.trim());


    if(statements.length>1){

        return {

            safe:false,
            reason:"ไม่อนุญาตหลาย SQL Statement"

        };

    }





    // ---------------------------------
    // Forbidden patterns
    // ---------------------------------

    for(const pattern of FORBIDDEN_PATTERNS){

        if(pattern.test(sql)){

            return {

                safe:false,
                reason:
                "พบคำสั่งที่ไม่ได้รับอนุญาต"

            };

        }

    }





    // ---------------------------------
    // Cross database reference
    // Example:
    // OtherDB.dbo.Table
    // ---------------------------------

    const dbRefPattern =
    /\[?(\w+)\]?\.\[?\w+\]?\.\[?\w+\]?/g;


    let match;


    while(
        (match=dbRefPattern.exec(sql))
        !==null
    ){

        const dbName =
        match[1];


        if(
            allowedDatabase &&
            dbName.toLowerCase()
            !==
            allowedDatabase.toLowerCase()
        ){

            return {

                safe:false,
                reason:
                `ห้ามอ้างอิง Database อื่น ${dbName}`

            };

        }

    }



    return {

        safe:true

    };

}



module.exports={
    isSafeQuery
};