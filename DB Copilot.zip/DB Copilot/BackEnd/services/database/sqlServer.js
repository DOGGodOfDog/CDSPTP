const sql = require("mssql");

// ------------------------------------------------------------
// Module-level state: only ONE active connection/database at a
// time. This is what makes "AI can only see the connected DB"
// enforceable — there is literally no other pool to query from.
// ------------------------------------------------------------
let pool = null;
let activeConfig = null; // { type, server, database, user }

/**
 * Opens a new connection pool and keeps it alive for reuse.
 * If a previous connection exists, it is closed first so the
 * app never has two databases "active" at once.
 */
async function connectSqlServer(config) {
  if (pool) {
    await pool.close().catch(() => {});
    pool = null;
    activeConfig = null;
  }

  pool = await new sql.ConnectionPool({
    server: config.server,
    database: config.database,
    user: config.username,
    password: config.password,
    options: {
      encrypt: false,
      trustServerCertificate: true
    },
    connectionTimeout: 5000,
    requestTimeout: 10000
  }).connect();

  activeConfig = {
    type: "SQL Server",
    server: config.server,
    database: config.database,
    user: config.username
  };

  return activeConfig;
}

/** Closes the active connection, if any. */
async function disconnectSqlServer() {
  if (pool) {
    await pool.close();
  }
  pool = null;
  activeConfig = null;
}

/** Returns { type, server, database, user } or null if not connected. */
function getActiveConnection() {
  return activeConfig;
}

/** Returns the live pool, or throws if nothing is connected. */
function getPool() {
  if (!pool) throw new Error("No active database connection");
  return pool;
}

module.exports = {
  connectSqlServer,
  disconnectSqlServer,
  getActiveConnection,
  getPool
};
