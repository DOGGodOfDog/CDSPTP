const sql = require("mssql");


let pool = null;

let activeConnection = null;


async function connectSqlServer(config){

    pool = await sql.connect({

        server: config.server,

        database: config.database,

        user: config.username,

        password: config.password,

        options:{
            encrypt:false,
            trustServerCertificate:true
        }

    });


    activeConnection = {

        type:"SQL Server",

        server:config.server,

        database:config.database,

        user:config.username

    };


    return activeConnection;

}



async function disconnectSqlServer(){

    if(pool){

        await pool.close();

        pool = null;

    }


    activeConnection = null;

}



function getActiveConnection(){

    return activeConnection;

}



function getPool(){

    return pool;

}



module.exports = {

    connectSqlServer,

    disconnectSqlServer,

    getActiveConnection,

    getPool

};