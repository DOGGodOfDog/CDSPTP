// ============================================================
// DB Copilot — app logic + AI chat wiring
// ============================================================

// ---------- State ----------
let isLoggedIn = false;
let isConnected = false;
let currentConnection = null;
let activePage = 'design'; // 'design' | 'assistant' | 'history'


const historyLog = []; // { page, question, answer, time }

// ---------- Element refs ----------
const btnUserMenu = document.getElementById('btnUserMenu');
const dropdownMenu = document.getElementById('dropdownMenu');
const btnMenuAction = document.getElementById('btnMenuAction');
const loginStatus = document.getElementById('loginStatus');
const currentUser = document.getElementById('currentUser');

const LoginModal = document.getElementById('LoginModal');
const closeLoginModal = document.getElementById('closeLoginModal');
const btnCancelLogin = document.getElementById('btnCancelLogin');
const btnLogin = document.getElementById('btnLogin');
const usernameInput = document.getElementById('username');
const passwordInput = document.getElementById('password');

const connectModal = document.getElementById('connectModal');
const btnConnect = document.getElementById('btnConnect');
const closeModal = document.getElementById('closeModal');
const btnCancel = document.getElementById('btnCancel');
const btnConnectDatabase = document.getElementById('btnConnectDatabase');
const btnTestConnection = document.getElementById('btnTestConnection');
const statusDot = document.getElementById('statusDot');
const statusText = document.getElementById('statusText');

const btnDesign = document.getElementById('btnDesign');
const btnAssistant = document.getElementById('btnAssistant');
const btnHistory = document.getElementById('btnHistory');
const pageDesign = document.getElementById('page-design');
const pageAssistant = document.getElementById('page-assistant');
const pageHistory = document.getElementById('page-history');
const historyList = document.getElementById('historyList');

const chatPanelDesign = document.getElementById('chatPanelDesign');
const chatPanelAssistant = document.getElementById('chatPanelAssistant');

const workflowDesign = document.getElementById('workflowDesign');
const workflowAssistant = document.getElementById('workflowAssistant');
const sqlPreviewDesign = document.getElementById('sqlPreviewDesign');
const sqlPreviewAssistant = document.getElementById('sqlPreviewAssistant');

const chatInput = document.getElementById('chatInput');
const btnGenerate = document.getElementById('btnGenerate');

// ============================================================
// Navigation
// ============================================================
function setActivePage(page){
  activePage = page;
  [btnDesign, btnAssistant, btnHistory].forEach(b => b.classList.remove('active'));
  [pageDesign, pageAssistant, pageHistory].forEach(p => p.style.display = 'none');

  if (page === 'design'){
    btnDesign.classList.add('active');
    pageDesign.style.display = '';
    chatInput.placeholder = 'Describe your database...';
  } else if (page === 'assistant'){
    btnAssistant.classList.add('active');
    pageAssistant.style.display = '';
    chatInput.placeholder = 'ถามเกี่ยวกับ SQL หรือฐานข้อมูล...';
  } else {
    btnHistory.classList.add('active');
    pageHistory.style.display = '';
    renderHistory();
  }
}

btnDesign.addEventListener('click', () => setActivePage('design'));
btnAssistant.addEventListener('click', () => setActivePage('assistant'));
btnHistory.addEventListener('click', () => setActivePage('history'));

// ============================================================
// User menu dropdown
// ============================================================
btnUserMenu.addEventListener('click', (e) => {
  e.stopPropagation();
  dropdownMenu.style.display = dropdownMenu.style.display === 'none' ? 'block' : 'none';
});
document.addEventListener('click', () => { dropdownMenu.style.display = 'none'; });

btnMenuAction.addEventListener('click', () => {
  dropdownMenu.style.display = 'none';
  if (isLoggedIn){
    // logout
    isLoggedIn = false;
    loginStatus.textContent = '🔴';
    currentUser.textContent = 'Guest';
    btnMenuAction.textContent = 'Login';
  } else {
    openModal(LoginModal);
  }
});

// ---------- Login modal ----------
function openModal(modal){ modal.classList.add('open'); }
function closeModalEl(modal){ modal.classList.remove('open'); }

closeLoginModal.addEventListener('click', () => closeModalEl(LoginModal));
btnCancelLogin.addEventListener('click', () => closeModalEl(LoginModal));
LoginModal.addEventListener('click', (e) => { if (e.target === LoginModal) closeModalEl(LoginModal); });

btnLogin.addEventListener('click', () => {
  const user = usernameInput.value.trim() || 'User';
  isLoggedIn = true;
  loginStatus.textContent = '🟢';
  currentUser.textContent = user;
  btnMenuAction.textContent = 'Logout';
  closeModalEl(LoginModal);
  usernameInput.value = '';
  passwordInput.value = '';
});

// ============================================================
// Connect database modal
// ============================================================
btnConnect.addEventListener('click', () => openModal(connectModal));
closeModal.addEventListener('click', () => closeModalEl(connectModal));
btnCancel.addEventListener('click', () => closeModalEl(connectModal));
connectModal.addEventListener('click', (e) => { if (e.target === connectModal) closeModalEl(connectModal); });

btnTestConnection.addEventListener("click", async ()=>{

    const payload = {
        type: document.getElementById("dbType").value,
        server: document.getElementById("server").value,
        database: document.getElementById("database").value,
        username: document.getElementById("dbUsername").value,
        password: document.getElementById("dbPassword").value
    };

    btnTestConnection.disabled = true;
    btnTestConnection.textContent = "Testing...";

    try{

        const res = await fetch(
            "http://localhost:3000/api/database/test",
            {
                method:"POST",
                headers:{
                    "Content-Type":"application/json"
                },
                body:JSON.stringify(payload)
            }
        );

        const data = await res.json();

        if(data.success){

            btnTestConnection.textContent="✅ Connected";

        }else{

            btnTestConnection.textContent="❌ Failed";

        }

    }
    catch{

        btnTestConnection.textContent="❌ Error";

    }

    setTimeout(()=>{

        btnTestConnection.disabled=false;
        btnTestConnection.textContent="Test Connection";

    },1500);

});

btnConnectDatabase.addEventListener('click', async () => {
  const payload = {
    type: document.getElementById('dbType').value,
    server: document.getElementById('server').value.trim() || 'localhost',
    database: document.getElementById('database').value.trim() || 'HR_DEV',
    username: document.getElementById('dbUsername').value.trim(),
    password: document.getElementById('dbPassword').value
  };

  try {
    const res = await fetch('http://localhost:3000/api/database/connect', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();

    if (!data.success) {
      alert('เชื่อมต่อไม่สำเร็จ: ' + data.message);
      return;
    }

    isConnected = true;
    currentConnection = {
      type: data.context.type,
      server: data.context.server,
      database: data.context.database,
      user: stripDomain(payload.username)
    };
    
    function stripDomain(username){

    if(!username) return "";

    if(username.includes("\\")){
        return username.split("\\").pop();
    }

    if(username.includes("@")){
        return username.split("@")[0];
    }

    return username;
}
    statusDot.textContent = '🟢';
    statusText.textContent = 'Connected';
    document.querySelectorAll('.connection-item span')[0].textContent = currentConnection.type;
    document.querySelectorAll('.connection-item span')[1].textContent = currentConnection.database;
    document.querySelectorAll('.connection-item span')[2].textContent = currentConnection.server;
    document.querySelectorAll('.connection-item span')[3].textContent = currentConnection.user;
    closeModalEl(connectModal);
  } catch (err) {
    alert('เชื่อมต่อ backend ไม่ได้: ' + err.message);
  }
});

// ============================================================
// Chat rendering helpers
// ============================================================
function escapeHtml(str){
  return str.replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
  }[c]));
}

function renderContent(text){
  const escaped = escapeHtml(text);
  let html = escaped.replace(/```(\w*)\n?([\s\S]*?)```/g, (m, lang, code) => {
    return `<pre>${code.trim()}</pre>`;
  });
  html = html.replace(/`([^`]+)`/g, '<code>$1</code>');
  return html;
}



function panelFor(page){ return page === 'design' ? chatPanelDesign : chatPanelAssistant; }
function workflowFor(page){ return page === 'design' ? workflowDesign : workflowAssistant; }
function sqlPreviewFor(page){ return page === 'design' ? sqlPreviewDesign : sqlPreviewAssistant; }

function addMessage(page, role, text){
  const panel = panelFor(page);
  const div = document.createElement('div');
  div.className = 'message ' + (role === 'user' ? 'user' : 'ai');
  const strong = document.createElement('strong');
  strong.textContent = role === 'user' ? 'คุณ' : 'DB Copilot';
  const p = document.createElement('p');
  p.innerHTML = renderContent(text);
  div.appendChild(strong);
  div.appendChild(p);
  panel.appendChild(div);
  panel.scrollTop = panel.scrollHeight;
}

function addTypingBubble(page){
  const panel = panelFor(page);
  const div = document.createElement('div');
  div.className = 'message ai';
  div.id = 'typingBubble-' + page;
  div.innerHTML = `<strong>DB Copilot</strong><div class="typing-dots"><span></span><span></span><span></span></div>`;
  panel.appendChild(div);
  panel.scrollTop = panel.scrollHeight;
}
function removeTypingBubble(page){
  const el = document.getElementById('typingBubble-' + page);
  if (el) el.remove();
}

function resetWorkflow(page){
  workflowFor(page).querySelectorAll('li').forEach(li => {
    li.className = '';
    li.textContent = '○ ' + li.textContent.replace(/^[○✔⏳]\s*/, '');
  });
}
async function animateWorkflow(page){
  const steps = workflowFor(page).querySelectorAll('li');
  for (let i = 0; i < steps.length; i++){
    steps[i].className = 'active';
    steps[i].textContent = '⏳ ' + steps[i].textContent.replace(/^[○✔⏳]\s*/, '');
    await new Promise(r => setTimeout(r, 280));
    steps[i].className = 'done';
    steps[i].textContent = '✔ ' + steps[i].textContent.replace(/^[○✔⏳]\s*/, '');
  }
}

function renderHistory(){
  if (historyLog.length === 0){
    historyList.innerHTML = '<p class="empty-hint">ยังไม่มีประวัติการสนทนา</p>';
    return;
  }
  historyList.innerHTML = '';
  [...historyLog].reverse().forEach(item => {
    const div = document.createElement('div');
    div.className = 'history-item';
    div.innerHTML = `
      <div class="h-q">💬 ${escapeHtml(item.question)}</div>
      <div class="h-meta">${item.page === 'design' ? '🗄 Database Design' : '💬 SQL Assistant'} · ${item.time}</div>
    `;
    historyList.appendChild(div);
  });
}

// ============================================================
// AI call
// ============================================================

async function askAI(page, userText) {
    const controller = new AbortController();
    // 1. ตั้งเวลา Timeout ไว้ที่ 3 นาที (180,000 ms)
    const timeoutId = setTimeout(() => controller.abort(), 180000); 

    try {
        const response = await fetch(
            "http://localhost:3000/api/agent/chat",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                signal: controller.signal,
                body: JSON.stringify({
                    message: userText,
                    page,
                    connection: currentConnection
                })
            }
        );

        if (!response.ok) {
            throw new Error(`HTTP Error: ${response.status}`);
        }

        const data = await response.json();

        if (!data.success) {
            throw new Error(data.message || "เกิดข้อผิดพลาดจากฝั่ง Server");
        }

        return data;

    } catch (err) {
        // ดักจับกรณีโดนตัดเวลา (Timeout 3 นาที) ชัดเจน
        if (err.name === 'AbortError') {
            console.error('❌ Request timed out (เกินเวลา 3 นาทีที่กำหนด)');
            return {
                success: false,
                answer: "ขออภัย AI ใช้เวลาประมวลผลนานเกินไป (Timeout 3 นาที)",
                sql: null
            };
        } else {
            console.error('❌ askAI Error:', err.message || err);
            return {
                success: false,
                answer: err.message || "เกิดข้อผิดพลาดในการเชื่อมต่อ AI",
                sql: null
            };
        }

    } finally {
        // 2. เคลียร์ timeout ออกเสมอ ไม่ว่าจะสำเร็จหรือล้มเหลว
        clearTimeout(timeoutId);
    }
}

// ============================================================
// Send flow (footer input drives whichever page is active)
// ============================================================
async function handleSend() {

    const text = chatInput.value.trim();

    if (!text) return;

    if (activePage === "history")
        setActivePage("design");

    const page = activePage;

    // แสดงข้อความผู้ใช้
    addMessage(page, "user", text);

    chatInput.value = "";

    btnGenerate.disabled = true;
    chatInput.disabled = true;

    resetWorkflow(page);

    const workflowPromise = animateWorkflow(page);

    addTypingBubble(page);

    try {

        const [response] = await Promise.all([
            askAI(page, text),
            workflowPromise
        ]);

        removeTypingBubble(page);

        // แสดงคำตอบ AI
        addMessage(page, "ai", response.answer);

        // SQL Preview
        if (response.sql) {
            sqlPreviewFor(page).textContent = response.sql;
        }

        // History
        historyLog.push({
            page,
            question: text,
            answer: response.answer,
            time: new Date().toLocaleTimeString("th-TH", {
                hour: "2-digit",
                minute: "2-digit"
            })
        });

    }
    catch (err) {

        removeTypingBubble(page);

        addMessage(page, "ai", "เกิดข้อผิดพลาด");

        console.error(err);

    }
    finally {

        btnGenerate.disabled = false;
        chatInput.disabled = false;
        chatInput.focus();

    }

}

btnGenerate.addEventListener("click", handleSend);

chatInput.addEventListener("keydown", e => {

    if (e.key === "Enter") {

        e.preventDefault();

        handleSend();

    }

});

setActivePage("design");
